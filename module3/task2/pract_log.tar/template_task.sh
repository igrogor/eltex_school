#!/bin/bash
NAME_SCRIPT=$(basename "$0")

echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> report_"${NAME_SCRIPT}".log

RANDOM_SECONDS=$(( ( RANDOM % 1771 ) + 30 ))
sleep "$RANDOM_SECONDS"
WORK_MINUTES=$(((RANDOM_SECONDS + 59) / 60))
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $WORK_MINUTES" >> report_"${NAME_SCRIPT}".log
