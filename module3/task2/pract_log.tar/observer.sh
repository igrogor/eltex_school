#!/bin/bash
while read -r script_name; do
	if ! pgrep -xf"$script_name"> /dev/null;then
		nohup "$script_name" > /dev/null 2>&1 &
		echo "[$(date '+%Y-%m-%d %H:%M:%S')] Перезапущен скрипт '$script_name'" >> observer.log
    	fi
done < config_scripts.txt
